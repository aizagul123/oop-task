class Brain {
    public void think() {
        System.out.println("Thinking...");
    }
}

