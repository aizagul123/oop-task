class Person {
    private final Brain brain;

    public Person() {
        brain = new Brain(); // Brain is created inside Person
    }

    public void think() {
        brain.think();
    }
}
