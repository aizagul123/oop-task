public class main {
    public static void main(String[] args) {
        Person person = new Person();
        person.think();
        // When person is deleted, the brain is also deleted (handled by garbage collection)
        person = null;
        System.gc(); // Suggest garbage collection
        System.out.println("Person object is deleted, so Brain no longer exists.");
    }
}