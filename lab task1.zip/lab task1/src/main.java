public class main {
    public static void main(String[] args) {
        Student s1 = new Student(101, "Aiza");
        Student s2 = new Student(102, "Ali");

        College college = new College("Riphah University");
        college.addStudent(s1);
        college.addStudent(s2);

        college.displayStudents();
    }
}
