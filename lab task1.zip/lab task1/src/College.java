
import java.util.ArrayList;
import java.util.List;

class College {
    private final String name;
    private final List<Student> students;

    public College(String name) {
        this.name = name;
        this.students = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void displayStudents() {
        System.out.println("College: " + name);
        for (Student s : students) {
            s.display();
        }
    }
}
